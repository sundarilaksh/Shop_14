import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom'; // Import useParams from react-router-dom
import './ProductDetail.css';
function ProductDetail() {
  const { productId } = useParams(); // Get the productId from the URL parameter
  const [product, setProduct] = useState(null);
  const apiUrl = `https://firestore.googleapis.com/v1/projects/digig-57d5f/databases/(default)/documents/Products/${productId}`;

  useEffect(() => {
    axios
      .get(apiUrl)
      .then((response) => {
        const productData = response.data.fields;
        setProduct(productData);
      })
      .catch((error) => {
        console.error('Error fetching product details: ', error);
      });
  }, [apiUrl, productId]);

  if (!product) {
    return <div>Loading...</div>;
  }

  return (
    <div className="product-detail-page">
      <h1>Product Details</h1>
      <div className="product-details">
        <img
          src={product.imageurl?.stringValue}
          alt={product.productname?.stringValue}
          className="product-image"
        />
        <strong><br></br>{product.productname?.stringValue}</strong>
        <p>Description: {product.description?.stringValue}</p>
        <p>Price: ₹{product.price?.integerValue}</p>
        <p>Stock: {product.stock?.integerValue}</p>
      </div>
    </div>
  );
}
export default ProductDetail;